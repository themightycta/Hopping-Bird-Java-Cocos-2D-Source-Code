package android.arch.lifecycle.viewmodel;

/* renamed from: android.arch.lifecycle.viewmodel.R */
public final class C0009R {
}
